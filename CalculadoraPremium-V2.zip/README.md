# Calculadora Premium

Aplicativo Android nativo em Kotlin. Projeto preparado para compilação por GitHub Actions.

**Criado por Paulo Albuquerque**

## Funcionalidades
- Calculadora com visual escuro, botões circulares e operadores em laranja.
- Ao tocar em `=`, abre em tela cheia: "Para saber o resultado, pague R$ 99,99" (sem pagamento real).
- O botão ✕ alterna para a opção de saída de R$ 1,99.
- Código secreto: tocar 4 vezes rápido no valor abre um teclado discreto; digite `1234` e `=` para ver o resultado.
- Saída de emergência: segurar o ✕ por 3 segundos. No modo especial, Voltar 2 vezes em até 2 s fecha o app.
- Nenhum pagamento é processado; não há integração com Pix/cartão nem coleta de dados.
- Ícone do aplicativo: calculadora.

## Compilar (GitHub Actions)
1. No repositório, envie este ZIP com o nome `CalculadoraPremium-V2.zip` (na raiz) e o arquivo `.github/workflows/build-apk-from-zip.yml`.
2. Abra **Actions** → **Build APK from ZIP** → **Run workflow** (também roda sozinho quando o ZIP é atualizado).
3. Ao terminar, baixe o artefato `CalculadoraPremium-debug-apk` (contém `app-debug.apk`).

Detalhes das correções em `RELATORIO-CORRECOES.md`. O APK é de depuração e ainda precisa ser testado em um dispositivo.
