package br.com.calculadorapremium

import android.animation.ObjectAnimator
import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.math.BigDecimal
import java.math.MathContext

class MainActivity : Activity() {

    private companion object {
        /** Código digitado no teclado + "=" para sair do modo especial (verificado só localmente). */
        const val SECRET_CODE = "1234"

        /** O modo especial abre automaticamente no N-ésimo cálculo concluído com "=". */
        const val CALCS_BEFORE_SPECIAL = 3

        /** Saída de emergência: segurar o botão ✕ por este tempo. */
        const val EMERGENCY_HOLD_MS = 3000L

        /** No modo especial, o Voltar só fecha o app se for tocado 2 vezes dentro deste intervalo. */
        const val BACK_CONFIRM_MS = 2000L

        val OFFERS = listOf("Acesso Premium" to "R$ 99,00", "Opção de saída" to "R$ 1,99")
        val OPERATORS = setOf("÷", "×", "−", "+")
        val FUNCTIONS = setOf("AC", "±", "%")
        val ROWS = listOf(
            listOf("AC", "±", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("⌫", "0", ".", "=")
        )
    }

    private val digitGray = Color.rgb(51, 51, 51)
    private val functionGray = Color.rgb(165, 165, 165)
    private val orange = Color.rgb(255, 159, 10)
    private val orangeLight = Color.rgb(255, 186, 80)
    private val orangeDeep = Color.rgb(255, 130, 0)
    private val subtle = Color.rgb(142, 142, 147)
    private val cardColor = Color.rgb(28, 28, 30)
    private val cardButton = Color.rgb(44, 44, 46)

    private lateinit var root: LinearLayout
    private lateinit var expressionView: TextView
    private lateinit var resultView: TextView
    private lateinit var offerCard: LinearLayout
    private lateinit var offerTitle: TextView
    private lateinit var offerValue: TextView
    private lateinit var closeButton: TextView
    private val keyViews = mutableMapOf<String, TextView>()
    private val keyBackgrounds = mutableMapOf<String, GradientDrawable>()
    private val handler = Handler(Looper.getMainLooper())

    private var expression = ""
    private var result = "0"
    private var lastExpression = ""
    private var justEvaluated = false
    private var showError = false
    private var activeOperator: String? = null
    private var calculations = 0
    private var specialMode = false
    private var offerIndex = 0
    private var secretBuffer = ""
    private var lastBackPress = 0L
    private var emergencyTriggered = false

    private val emergencyExit = Runnable {
        emergencyTriggered = true
        closeButton.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        exitSpecialMode()
    }

    private val pressAnimator = View.OnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(70).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        savedInstanceState?.let { s ->
            expression = s.getString("expression") ?: ""
            result = s.getString("result") ?: "0"
            lastExpression = s.getString("lastExpression") ?: ""
            justEvaluated = s.getBoolean("justEvaluated")
            calculations = s.getInt("calculations")
            specialMode = s.getBoolean("specialMode")
            offerIndex = s.getInt("offerIndex")
        }
        buildInterface()
        if (specialMode) {
            updateOffer(animate = false)
            offerCard.visibility = View.VISIBLE
        }
        render()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("expression", expression)
        outState.putString("result", result)
        outState.putString("lastExpression", lastExpression)
        outState.putBoolean("justEvaluated", justEvaluated)
        outState.putInt("calculations", calculations)
        outState.putBoolean("specialMode", specialMode)
        outState.putInt("offerIndex", offerIndex)
    }

    override fun onDestroy() {
        handler.removeCallbacks(emergencyExit)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- interface

    private fun buildInterface() {
        val side = dp(16)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(side, dp(8), side, dp(16))
        }
        // targetSdk 35: o Android 15 desenha atrás das barras do sistema; aplica as margens seguras.
        root.setOnApplyWindowInsetsListener { v, insets ->
            val bars = systemBarInsets(insets)
            v.setPadding(side + bars[0], dp(8) + bars[1], side + bars[2], dp(16) + bars[3])
            insets
        }

        val title = TextView(this).apply {
            text = "Calculadora Premium"
            setTextColor(subtle)
            textSize = 13f
            letterSpacing = 0.04f
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        offerCard = buildOfferCard()
        root.addView(offerCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
        val display = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(8), 0, dp(8), dp(10))
        }
        expressionView = TextView(this).apply {
            setTextColor(subtle)
            textSize = 24f
            gravity = Gravity.END
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.START
            typeface = light
        }
        resultView = TextView(this).apply {
            setTextColor(Color.WHITE)
            gravity = Gravity.END
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.START
            includeFontPadding = false
            typeface = light
        }
        display.addView(expressionView, LinearLayout.LayoutParams(-1, -2))
        display.addView(resultView, LinearLayout.LayoutParams(-1, -2))
        root.addView(display, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(buildKeypad(), LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun buildKeypad(): LinearLayout {
        val dm = resources.displayMetrics
        val usableW = dm.widthPixels - dp(32)
        val gap = maxOf(dp(8), (usableW * 0.035f).toInt())
        val byWidth = (usableW - 3 * gap) / 4
        val byHeight = ((dm.heightPixels * 0.58f).toInt() - 4 * gap) / 5
        val size = minOf(byWidth, byHeight, dp(92)).coerceAtLeast(dp(40))

        val pad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        ROWS.forEachIndexed { r, row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEachIndexed { c, key ->
                line.addView(buildKey(key, size), LinearLayout.LayoutParams(size, size).apply {
                    if (c > 0) leftMargin = gap
                })
            }
            pad.addView(line, LinearLayout.LayoutParams(-1, -2).apply { if (r > 0) topMargin = gap })
        }
        return pad
    }

    private fun buildKey(key: String, size: Int): TextView {
        val bg = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        val view = TextView(this).apply {
            text = key
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_PX, size * if (key == "AC") 0.32f else 0.40f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = RippleDrawable(ColorStateList.valueOf(Color.argb(70, 255, 255, 255)), bg, null)
            isClickable = true
            isFocusable = true
            contentDescription = describeKey(key)
            setOnTouchListener(pressAnimator)
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                onKey(key)
            }
        }
        // Ação definida no projeto: segurar "=" abre o modo especial na hora.
        if (key == "=") view.setOnLongClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            if (!specialMode) evaluate(forceSpecial = true)
            true
        }
        keyBackgrounds[key] = bg
        keyViews[key] = view
        styleKey(key)
        return view
    }

    private fun styleKey(key: String) {
        val bg = keyBackgrounds[key] ?: return
        val view = keyViews[key] ?: return
        when {
            key == "=" -> {
                bg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM)
                bg.setColors(intArrayOf(orangeLight, orangeDeep))
                view.setTextColor(Color.WHITE)
            }
            key in OPERATORS -> if (key == activeOperator && !specialMode) {
                bg.setColor(Color.WHITE)
                view.setTextColor(orange)
            } else {
                bg.setColor(orange)
                view.setTextColor(Color.WHITE)
            }
            key in FUNCTIONS -> {
                bg.setColor(functionGray)
                view.setTextColor(Color.BLACK)
            }
            else -> {
                bg.setColor(digitGray)
                view.setTextColor(Color.WHITE)
            }
        }
    }

    private fun buildOfferCard(): LinearLayout {
        val photo = ImageView(this).apply {
            setImageResource(R.drawable.payment_dog)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Calculadora Premium"
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
            clipToOutline = true
        }
        offerTitle = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
        }
        offerValue = TextView(this).apply {
            setTextColor(orange)
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
        }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(offerTitle)
            addView(offerValue)
        }
        closeButton = TextView(this).apply {
            text = "✕"
            gravity = Gravity.CENTER
            textSize = 16f
            setTextColor(Color.rgb(174, 174, 178))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(cardButton)
            }
            contentDescription = "Sair"
            isClickable = true
            setOnClickListener {
                if (emergencyTriggered) emergencyTriggered = false else nextOffer()
            }
            // Saída de emergência: segurar o ✕ por 3 s (o botão vai esmaecendo enquanto segura).
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        emergencyTriggered = false
                        handler.postDelayed(emergencyExit, EMERGENCY_HOLD_MS)
                        v.animate().alpha(0.3f).setDuration(EMERGENCY_HOLD_MS).start()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        handler.removeCallbacks(emergencyExit)
                        v.animate().cancel()
                        v.alpha = 1f
                    }
                }
                false
            }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(cardColor)
            }
            setPadding(dp(12), dp(12), dp(12), dp(12))
            addView(photo, LinearLayout.LayoutParams(dp(56), dp(56)))
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply {
                leftMargin = dp(14)
                rightMargin = dp(8)
            })
            addView(closeButton, LinearLayout.LayoutParams(dp(40), dp(40)))
            visibility = View.GONE
        }
    }

    // ---------------------------------------------------------------- lógica

    private fun onKey(key: String) {
        if (specialMode) {
            onSpecialKey(key)
            return
        }
        showError = false
        when (key) {
            "AC" -> {
                expression = ""; result = "0"; lastExpression = ""
                justEvaluated = false; activeOperator = null
            }
            "⌫" -> {
                expression = expression.dropLast(1); result = "0"
                justEvaluated = false; activeOperator = null
            }
            "=" -> {
                evaluate()
                return
            }
            "±" -> {
                if (expression.startsWith("-")) expression = expression.drop(1)
                else if (expression.isNotEmpty()) expression = "-$expression"
                justEvaluated = false
            }
            "%" -> {
                val value = expression.toBigDecimalOrNull()
                if (value != null) expression = value.divide(BigDecimal(100)).stripTrailingZeros().toPlainString()
                else expression += "%"
                justEvaluated = false
            }
            else -> {
                val token = when (key) {
                    "÷" -> "/"
                    "×" -> "*"
                    "−" -> "-"
                    else -> key
                }
                // Depois do "=", digitar um número começa uma conta nova; um operador continua do resultado.
                if (justEvaluated && key !in OPERATORS) {
                    expression = ""
                    lastExpression = ""
                }
                expression += token
                justEvaluated = false
                activeOperator = if (key in OPERATORS) key else null
            }
        }
        render()
    }

    private fun evaluate(forceSpecial: Boolean = false) {
        activeOperator = null
        if (expression.isNotBlank()) {
            try {
                val value = calculate(expression).stripTrailingZeros().toPlainString()
                lastExpression = expression
                result = value
                expression = value
                justEvaluated = true
                calculations++
            } catch (_: Exception) {
                showError = true
                render()
                shake(resultView)
                return
            }
        }
        if (forceSpecial || calculations >= CALCS_BEFORE_SPECIAL) {
            enterSpecialMode()
        } else {
            render()
            pulse(resultView)
        }
    }

    private fun onSpecialKey(key: String) {
        // Tela congelada: as teclas respondem ao toque, mas o visor não muda.
        when {
            key.length == 1 && key[0].isDigit() -> if (secretBuffer.length < 12) secretBuffer += key
            key == "AC" -> secretBuffer = ""
            key == "⌫" -> secretBuffer = secretBuffer.dropLast(1)
            key == "=" -> {
                if (secretBuffer == SECRET_CODE) {
                    exitSpecialMode()
                } else {
                    secretBuffer = ""
                    shake(resultView)
                }
            }
        }
    }

    private fun enterSpecialMode() {
        specialMode = true
        offerIndex = 0
        secretBuffer = ""
        activeOperator = null
        updateOffer(animate = false)
        offerCard.animate().cancel()
        offerCard.visibility = View.VISIBLE
        offerCard.alpha = 0f
        offerCard.translationY = -dp(16).toFloat()
        offerCard.animate().alpha(1f).translationY(0f).setDuration(320).start()
        render()
    }

    private fun exitSpecialMode() {
        handler.removeCallbacks(emergencyExit)
        specialMode = false
        secretBuffer = ""
        calculations = 0
        offerIndex = 0
        expression = ""
        result = "0"
        lastExpression = ""
        justEvaluated = false
        showError = false
        activeOperator = null
        offerCard.animate().cancel()
        offerCard.animate().alpha(0f).translationY(-dp(16).toFloat()).setDuration(220)
            .withEndAction { offerCard.visibility = View.GONE }
            .start()
        render()
        pulse(resultView)
    }

    private fun nextOffer() {
        offerIndex = (offerIndex + 1) % OFFERS.size
        updateOffer(animate = true)
    }

    private fun updateOffer(animate: Boolean) {
        val (title, value) = OFFERS[offerIndex]
        if (!animate) {
            offerTitle.text = title
            offerValue.text = value
            return
        }
        offerValue.animate().alpha(0f).setDuration(120).withEndAction {
            offerTitle.text = title
            offerValue.text = value
            offerValue.animate().alpha(1f).setDuration(180).start()
        }.start()
    }

    private fun render() {
        val big = when {
            showError -> "Erro"
            specialMode -> result
            expression.isNotEmpty() -> pretty(expression)
            else -> result
        }
        val small = if (justEvaluated || specialMode) pretty(lastExpression) else ""
        expressionView.text = small.ifEmpty { " " }
        setFitted(resultView, big)
        OPERATORS.forEach { styleKey(it) }
    }

    @Deprecated("Mantido para controlar o Voltar em todas as versões do Android.")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (!specialMode) {
            super.onBackPressed()
            return
        }
        // Evita saída por toque acidental, mas nunca bloqueia: 2 toques em até 2 s fecham o app.
        val now = SystemClock.elapsedRealtime()
        if (now - lastBackPress < BACK_CONFIRM_MS) {
            finish()
        } else {
            lastBackPress = now
            shake(offerCard)
        }
    }

    // ---------------------------------------------------------------- utilidades

    private fun pretty(raw: String): String =
        raw.replace('*', '×').replace('/', '÷').replace('-', '−')

    private fun describeKey(key: String): String = when (key) {
        "AC" -> "Limpar"
        "⌫" -> "Apagar"
        "±" -> "Inverter sinal"
        "%" -> "Porcentagem"
        "÷" -> "Dividir"
        "×" -> "Multiplicar"
        "−" -> "Subtrair"
        "+" -> "Somar"
        "=" -> "Igual"
        "." -> "Ponto decimal"
        else -> key
    }

    private fun setFitted(view: TextView, value: String) {
        val dm = resources.displayMetrics
        val maxPx = minOf(sp(84f), dm.widthPixels * 0.22f, dm.heightPixels * 0.13f)
        val minPx = sp(28f)
        val available = if (view.width > 0) {
            (view.width - view.paddingLeft - view.paddingRight).toFloat()
        } else {
            (dm.widthPixels - dp(48)).toFloat()
        }
        val paint = TextPaint(view.paint)
        var size = maxPx
        paint.textSize = size
        while (size > minPx && paint.measureText(value) > available) {
            size -= 2f
            paint.textSize = size
        }
        view.setTextSize(TypedValue.COMPLEX_UNIT_PX, size)
        view.text = value
    }

    private fun shake(v: View) {
        ObjectAnimator.ofFloat(v, "translationX", 0f, 18f, -18f, 12f, -12f, 6f, 0f)
            .setDuration(360)
            .start()
    }

    private fun pulse(v: View) {
        v.alpha = 0.35f
        v.animate().alpha(1f).setDuration(220).start()
    }

    private fun systemBarInsets(insets: WindowInsets): IntArray =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            intArrayOf(i.left, i.top, i.right, i.bottom)
        } else {
            @Suppress("DEPRECATION")
            intArrayOf(
                insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                insets.systemWindowInsetRight, insets.systemWindowInsetBottom
            )
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun sp(value: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, value, resources.displayMetrics)

    // Recursive-descent parser: supports +, -, *, /, %, unary signs and parentheses.
    private fun calculate(raw: String): BigDecimal {
        val parser = ExpressionParser(raw)
        val value = parser.parse()
        if (!parser.isAtEnd()) throw IllegalArgumentException("Unexpected input")
        return value.round(MathContext.DECIMAL64)
    }

    private class ExpressionParser(private val input: String) {
        private var pos = 0
        fun isAtEnd() = pos >= input.length
        fun parse(): BigDecimal = expression()
        private fun expression(): BigDecimal {
            var value = term()
            while (true) {
                skipSpaces()
                value = when {
                    take('+') -> value.add(term())
                    take('-') -> value.subtract(term())
                    else -> return value
                }
            }
        }
        private fun term(): BigDecimal {
            var value = factor()
            while (true) {
                skipSpaces()
                value = when {
                    take('*') -> value.multiply(factor())
                    take('/') -> value.divide(factor(), MathContext.DECIMAL64)
                    take('%') -> value.divide(BigDecimal(100)).multiply(factor())
                    else -> return value
                }
            }
        }
        private fun factor(): BigDecimal {
            skipSpaces()
            if (take('+')) return factor()
            if (take('-')) return factor().negate()
            if (take('(')) {
                val v = expression()
                skipSpaces()
                if (!take(')')) throw IllegalArgumentException("Missing )")
                return v
            }
            val start = pos
            var dot = false
            while (pos < input.length) {
                val c = input[pos]
                if (c.isDigit()) pos++
                else if (c == '.' && !dot) { dot = true; pos++ }
                else break
            }
            if (start == pos) throw IllegalArgumentException("Number expected")
            return input.substring(start, pos).toBigDecimal()
        }
        private fun skipSpaces() { while (pos < input.length && input[pos].isWhitespace()) pos++ }
        private fun take(c: Char): Boolean {
            if (pos < input.length && input[pos] == c) { pos++; return true }
            return false
        }
    }
}
