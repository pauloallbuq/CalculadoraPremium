package br.com.calculadorapremium

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.ImageView
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var expressionView: TextView
    private lateinit var resultView: TextView
    private var expression = ""
    private var result = "0"
    private var showingPayment = false
    private var showingExit = false

    private val bg = Color.rgb(250, 250, 250)
    private val ink = Color.rgb(32, 33, 36)
    private val muted = Color.rgb(95, 99, 104)
    private val accent = Color.rgb(26, 115, 232)
    private val soft = Color.rgb(241, 243, 244)
    private val warning = Color.rgb(255, 248, 225)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showCalculator()
    }

    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(18), dp(20), dp(18))
            layoutParams = LinearLayout.LayoutParams(-1, -1)
        }
    }

    private fun showCalculator() {
        showingPayment = false
        showingExit = false
        root = baseLayout()
        val header = text("Calculadora Premium\\nCriado por Paulo Albuquerque", 20f, ink, true).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(12))
        }
        root.addView(header, LinearLayout.LayoutParams(-1, dp(56)))

        val display = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(12), dp(16), dp(12), dp(20))
        }
        expressionView = text(expression.ifBlank { " " }, 22f, muted, false).apply {
            gravity = Gravity.END
            maxLines = 2
        }
        resultView = text(result, 42f, ink, false).apply {
            gravity = Gravity.END
            maxLines = 1
        }
        display.addView(expressionView, LinearLayout.LayoutParams(-1, 0, 1f))
        display.addView(resultView, LinearLayout.LayoutParams(-1, dp(66)))
        root.addView(display, LinearLayout.LayoutParams(-1, 0, 1.2f))

        val rows = listOf(
            listOf("AC", "⌫", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("±", "0", ".", "=")
        )
        rows.forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { key ->
                val b = Button(this).apply {
                    text = key
                    textSize = 22f
                    isAllCaps = false
                    setTextColor(if (key in listOf("÷", "×", "−", "+", "=")) accent else ink)
                    setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                        if (key == "=") Color.rgb(232, 240, 254) else soft
                    ))
                    setOnClickListener { onKey(key) }
                }
                val lp = LinearLayout.LayoutParams(0, 0, 1f).apply {
                    height = dp(62)
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                }
                line.addView(b, lp)
            }
            root.addView(line, LinearLayout.LayoutParams(-1, dp(70)))
        }
        setContentView(root)
        updateDisplay()
    }

    private fun onKey(key: String) {
        when (key) {
            "AC" -> { expression = ""; result = "0" }
            "⌫" -> { expression = expression.dropLast(1); result = "0" }
            "=" -> {
                if (expression.isNotBlank()) {
                    try {
                        result = calculate(expression).stripTrailingZeros().toPlainString()
                        expression = result
                        updateDisplay()
                        showPayment()
                        return
                    } catch (_: Exception) {
                        Toast.makeText(this, "Conta inválida", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            "±" -> {
                if (expression.startsWith("-")) expression = expression.drop(1)
                else if (expression.isNotEmpty()) expression = "-$expression"
            }
            "%" -> {
                val value = expression.toBigDecimalOrNull()
                if (value != null) expression = value.divide(BigDecimal(100)).stripTrailingZeros().toPlainString()
                else expression += "%"
            }
            else -> expression += when (key) {
                "÷" -> "/"
                "×" -> "*"
                "−" -> "-"
                else -> key
            }
        }
        updateDisplay()
    }

    private fun updateDisplay() {
        if (::expressionView.isInitialized) expressionView.text = expression.ifBlank { " " }
        if (::resultView.isInitialized) resultView.text = result
    }

    private fun showPayment() {
        showingPayment = true
        showingExit = false
        root = baseLayout()
        root.gravity = Gravity.CENTER
        root.addView(text("Resultado calculado", 16f, muted, false).apply { gravity = Gravity.CENTER })
        root.addView(text(result, 44f, ink, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(22))
        })
        root.addView(text("Acesso Premium", 28f, ink, true).apply { gravity = Gravity.CENTER })
        val photo = ImageView(this).apply {
            setImageResource(R.drawable.payment_dog)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Imagem da brincadeira"
        }
        root.addView(photo, LinearLayout.LayoutParams(-1, dp(220)).apply {
            setMargins(0, dp(12), 0, dp(12))
        })
        root.addView(text("Para continuar, o acesso demonstrativo apresenta uma taxa fictícia.", 17f, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(14), dp(8), dp(18))
        })
        root.addView(text("R$ 99,00", 36f, accent, true).apply { gravity = Gravity.CENTER })
        root.addView(text("SIMULAÇÃO — NENHUM PAGAMENTO SERÁ REALIZADO.", 13f, Color.rgb(140, 90, 0), true).apply {
            gravity = Gravity.CENTER
            setBackgroundColor(warning)
            setPadding(dp(10), dp(12), dp(10), dp(12))
        }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(22), 0, dp(18)) })
        val x = Button(this).apply {
            text = "X — Ver opção de saída"
            isAllCaps = false
            textSize = 16f
            setOnClickListener { showExitOffer() }
        }
        root.addView(x, LinearLayout.LayoutParams(-1, dp(56)))
        val back = Button(this).apply {
            text = "Voltar à calculadora"
            isAllCaps = false
            setOnClickListener { showCalculator() }
        }
        root.addView(back, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
        setContentView(root)
    }

    private fun showExitOffer() {
        showingExit = true
        root = baseLayout()
        root.gravity = Gravity.CENTER
        root.addView(text("Opção de saída", 28f, ink, true).apply { gravity = Gravity.CENTER })
        val photo = ImageView(this).apply {
            setImageResource(R.drawable.payment_dog)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Imagem da brincadeira"
        }
        root.addView(photo, LinearLayout.LayoutParams(-1, dp(220)).apply {
            setMargins(0, dp(12), 0, dp(12))
        })
        root.addView(text("Valor de saída demonstrativo", 17f, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(8))
        })
        root.addView(text("R$ 1,99", 42f, accent, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(22))
        })
        root.addView(text("Isto é uma brincadeira. Não há cobrança, Pix, cartão ou coleta de dados.", 15f, ink, false).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(14), dp(12), dp(20))
            setBackgroundColor(warning)
        }, LinearLayout.LayoutParams(-1, -2))
        val back = Button(this).apply {
            text = "Voltar à calculadora"
            isAllCaps = false
            setOnClickListener { showCalculator() }
        }
        root.addView(back, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(18) })
        val stay = Button(this).apply {
            text = "Voltar à tela anterior"
            isAllCaps = false
            setOnClickListener { showPayment() }
        }
        root.addView(stay, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        setContentView(root)
    }

    override fun onBackPressed() {
        if (showingExit) showPayment()
        else if (showingPayment) showCalculator()
        else super.onBackPressed()
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    // Recursive-descent parser: supports +, -, *, /, %, unary signs and parentheses.
    private fun calculate(raw: String): BigDecimal {
        val parser = ExpressionParser(raw)
        val value = parser.parse()
        if (!parser.isAtEnd()) throw IllegalArgumentException("Unexpected input")
        return value.round(MathContext.DECIMAL64)
    }

    private class ExpressionParser(private val input: String) {
        private var pos = 0
        fun isAtEnd() = pos >= input.length
        fun parse(): BigDecimal = expression()
        private fun expression(): BigDecimal {
            var value = term()
            while (true) {
                skipSpaces()
                value = when {
                    take('+') -> value.add(term())
                    take('-') -> value.subtract(term())
                    else -> return value
                }
            }
        }
        private fun term(): BigDecimal {
            var value = factor()
            while (true) {
                skipSpaces()
                value = when {
                    take('*') -> value.multiply(factor())
                    take('/') -> value.divide(factor(), MathContext.DECIMAL64)
                    take('%') -> value.divide(BigDecimal(100)).multiply(factor())
                    else -> return value
                }
            }
        }
        private fun factor(): BigDecimal {
            skipSpaces()
            if (take('+')) return factor()
            if (take('-')) return factor().negate()
            if (take('(')) {
                val v = expression()
                skipSpaces()
                if (!take(')')) throw IllegalArgumentException("Missing )")
                return v
            }
            val start = pos
            var dot = false
            while (pos < input.length) {
                val c = input[pos]
                if (c.isDigit()) pos++
                else if (c == '.' && !dot) { dot = true; pos++ }
                else break
            }
            if (start == pos) throw IllegalArgumentException("Number expected")
            return input.substring(start, pos).toBigDecimal()
        }
        private fun skipSpaces() { while (pos < input.length && input[pos].isWhitespace()) pos++ }
        private fun take(c: Char): Boolean {
            if (pos < input.length && input[pos] == c) { pos++; return true }
            return false
        }
    }
}
