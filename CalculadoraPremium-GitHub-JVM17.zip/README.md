# Calculadora Premium

Aplicativo Android nativo em Kotlin. Projeto preparado para compilação por GitHub Actions.

**Criado por Paulo Albuquerque**

## Funcionalidades
- Calculadora básica.
- Ao tocar em `=`, abre uma tela de brincadeira com valor fictício de R$ 99,00.
- O botão `X` abre a opção fictícia de saída por R$ 1,99.
- A foto fornecida pelo autor aparece nas telas de brincadeira.
- Nenhum pagamento é processado; não há integração com Pix/cartão nem coleta de dados.
- Ícone do aplicativo: calculadora.

## Compilar
1. Envie todos os arquivos deste projeto para a raiz de um repositório GitHub.
2. Abra **Actions** e execute **Build Android APK**.
3. Baixe o artefato `CalculadoraPremium-debug-apk` quando a execução terminar.

O APK é de depuração e ainda precisa ser testado em um dispositivo.
