# Calculadora Premium

Aplicativo Android nativo em Kotlin. Projeto preparado para compilação por GitHub Actions.

**Criado por Paulo Albuquerque**

## Funcionalidades
- Calculadora básica.
- Ao tocar em `=`, abre uma tela de brincadeira com valor fictício de R$ 99,00.
- O botão `X` abre a opção fictícia de saída por R$ 1,99.
- A foto fornecida pelo autor aparece nas telas de brincadeira.
- Nenhum pagamento é processado; não há integração com Pix/cartão nem coleta de dados.
- Ícone do aplicativo: calculadora.

## Compilar (GitHub Actions)
1. No repositório, envie este ZIP com o nome `CalculadoraPremium-GitHub.zip` (na raiz) e o arquivo `.github/workflows/build-apk-from-zip.yml`.
2. Abra **Actions** → **Build APK from ZIP** → **Run workflow** (também roda sozinho quando o ZIP é atualizado).
3. Ao terminar, baixe o artefato `CalculadoraPremium-debug-apk` (contém `app-debug.apk`).

Detalhes das correções em `RELATORIO-CORRECOES.md`. O APK é de depuração e ainda precisa ser testado em um dispositivo.
