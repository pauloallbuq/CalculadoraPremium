# Relatório de correções — Calculadora Premium

## 1. Auditoria

| Item | Valor encontrado | Situação |
|---|---|---|
| Estrutura do ZIP | Projeto Android direto na raiz do ZIP (`settings.gradle.kts`, `app/`), sem pasta intermediária | OK |
| Gradle (CI) | 8.9 | Compatível com AGP 8.7.3 (mínimo exigido: 8.9) |
| Android Gradle Plugin | 8.7.3 | OK, `compileSdk 35` suportado |
| Kotlin Gradle Plugin | 2.0.21 | OK |
| Java `source/targetCompatibility` | 17 | OK |
| Kotlin `jvmTarget` | 17 | OK — igual ao Java (sem erro "Inconsistent JVM-target") |
| minSdk / targetSdk / compileSdk | 23 / 35 / 35 | OK |
| Dependências | Nenhuma externa (só Android framework + stdlib Kotlin, adicionada automaticamente) | OK |
| Manifesto | Activity launcher `exported=true`, ícone `@drawable/ic_calculator` | OK |
| Recursos | `ic_calculator.xml` (vetor), `payment_dog.jpg` (JPEG 1152×1536) | ver bug 3 |

## 2. Investigação do `:app:compileDebugKotlin FAILED`

O Google Maven e o Android SDK estão bloqueados no ambiente onde a análise foi feita, então **não foi possível rodar o Gradle/AGP completo**. Para reproduzir a tarefa `compileDebugKotlin`, o `MainActivity.kt` foi compilado com **o mesmo compilador Kotlin 2.0.21** usado pelo projeto (`kotlin-compiler-embeddable-2.0.21`), com `-jvm-target 17`, contra stubs das classes Android usadas (assinaturas iguais às do SDK 35).

Resultado com o código **original deste ZIP**: compila, **0 erros**, 2 avisos de depreciação (`onBackPressed`). Avisos não derrubam a tarefa (o projeto não usa `allWarningsAsErrors`).

Conclusão honesta: o código deste ZIP ("JVM17") não reproduz o erro. A causa mais provável da falha no seu Actions é que o `CalculadoraPremium-GitHub.zip` que estava no repositório era uma versão anterior (o nome "JVM17" indica que o alvo JVM já tinha sido ajustado; o erro clássico nesse cenário é *Inconsistent JVM-target compatibility*, que aparece exatamente em `compileDebugKotlin`). Como não há o log detalhado da execução antiga, isso não pode ser confirmado. Por isso o novo workflow foi feito para **mostrar o erro real** se algo ainda falhar (ver seção 4).

## 3. Bugs encontrados e corrigidos

### Bug 1 — Cabeçalho mostrava `\n` literal
- **Causa:** `"Calculadora Premium\\nCriado por Paulo Albuquerque"` — a barra dupla vira o texto `\n` na tela, em vez de quebra de linha.
- **Correção:** trocado por `\n` (quebra de linha real).

### Bug 2 — Cabeçalho cortado
- **Causa:** a altura fixa de 56dp não comporta duas linhas de 20sp + padding; após a correção do bug 1 a segunda linha ficaria cortada.
- **Correção:** altura alterada para `WRAP_CONTENT`.

### Bug 3 — Possível crash ao abrir a tela de pagamento em celulares de alta densidade
- **Causa:** `payment_dog.jpg` (1152×1536) estava em `res/drawable/` (sem qualificador = mdpi). O Android amplia a imagem pela densidade: em xxxhdpi (4×) o bitmap vira 4608×6144 ≈ 113 MB, acima do limite de ~100 MB do `Canvas` → `RuntimeException: Canvas: trying to draw too large bitmap`. Em xxhdpi ≈ 64 MB (risco de falta de memória).
- **Correção:** imagem movida, **sem alteração** (arquivo idêntico, byte a byte), para `res/drawable-nodpi/`. O nome do recurso (`R.drawable.payment_dog`) e o código continuam iguais.

### Bug 4 — Avisos de depreciação em `onBackPressed`
- **Causa:** `Activity.onBackPressed()` está depreciado desde a API 33.
- **Correção:** adicionados `@Deprecated` e `@Suppress("DEPRECATION")`. Comportamento mantido (com `targetSdk 35` e sem opt-in de *predictive back*, o método continua sendo chamado). Agora o arquivo compila com `-Werror` (zero avisos).

### Bug 5 — Workflow antigo não correspondia ao processo pedido
- **Causa:** `.github/workflows/build-apk.yml` compilava a partir da raiz do repositório, não extraía o ZIP e não exibia os erros do Kotlin de forma destacada.
- **Correção:** substituído por `.github/workflows/build-apk-from-zip.yml` (seção 4). O arquivo antigo foi removido do ZIP; **apague-o também do repositório**, senão ele falha a cada push.

Nada foi removido: calculadora, parser de expressões, telas de brincadeira (R$ 99,00 / R$ 1,99), avisos de simulação, ícone e imagem foram preservados. Nenhum pagamento real ou coleta de dados foi adicionado.

## 4. Workflow `build-apk-from-zip.yml`
1. Disparo manual (Actions → Run workflow) e automático quando `CalculadoraPremium-GitHub.zip` ou o workflow mudam.
2. Valida o ZIP (`unzip -t`), extrai e **procura** o `settings.gradle.kts` (não supõe pasta fixa). Sem ZIP, usa o projeto na raiz do repositório.
3. Confere arquivos obrigatórios (manifesto, MainActivity, ícone, imagem).
4. JDK 17 (Temurin), Gradle 8.9, Android SDK (platform 35, build-tools 35.0.0) e aceite de licenças.
5. `gradle assembleDebug --stacktrace` com o compilador Kotlin *in-process*: as linhas `e: arquivo.kt:linha:coluna mensagem` aparecem no log e como anotações de erro na execução. Se falhar, o log completo é publicado como artefato `gradle-build-log`.
6. Verifica e publica `app/build/outputs/apk/debug/app-debug.apk` como **`CalculadoraPremium-debug-apk`**.

## 5. Testes realizados (resultados reais)

| Teste | Resultado |
|---|---|
| Integridade do ZIP original (`unzip -t`) | OK, sem erros |
| Compilação Kotlin 2.0.21, JVM 17, do código original | OK — 0 erros, 2 avisos |
| Compilação Kotlin 2.0.21, JVM 17, `-Werror`, do código corrigido | OK — 0 erros, 0 avisos |
| Parser: `2+3*4`=14, `10/4`=2.5, `1/3`=0.3333333333333333, `50%200`=100, `-5+2`=-3, `2*(3+4)`=14, `0.1+0.2`=0.3 | OK |
| Parser: `7/0`, `2+`, `1.2.3` lançam exceção (capturada → toast "Conta inválida") | OK |
| Imagem preservada (comparação byte a byte) | Idêntica |
| Sintaxe YAML do workflow | Válida |
| Simulação do passo "extrair ZIP e localizar projeto" sobre o ZIP final | OK |
| Caminho do APK = padrão do AGP (`app/build/outputs/apk/debug/app-debug.apk`) | Conferido |
| **Build Gradle/AGP completo e geração do APK** | **Não executado** — Google Maven e Android SDK bloqueados neste ambiente. A confirmação final é a execução no GitHub Actions. |
| Testes automatizados existentes | Não há no projeto |
